//A class that starts the game!

public class START 
{
    public static void main(String[] p){
            GameFrame.main();
    }
}
